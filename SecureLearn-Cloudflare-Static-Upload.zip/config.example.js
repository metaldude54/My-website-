// Copy this file to config.js and replace the placeholders with your project's
// public Supabase URL and anon key. These are client-side values; NEVER put a
// service-role key or Cloudflare secret in this file.
window.SECURELEARN_SUPABASE_URL = "https://YOUR-PROJECT.supabase.co";
window.SECURELEARN_SUPABASE_ANON_KEY = "YOUR_PUBLIC_ANON_KEY";