SECURELEARN — CLOUDFLARE STATIC UPLOAD

This folder is for the Cloudflare drag-and-drop static asset uploader.

1. Upload the CONTENTS of this folder (the HTML, CSS, JS files), or zip this folder's contents.
2. Do NOT upload wrangler.toml or package.json with the static uploader.
3. This is a frontend starter. Real signup/login requires configuring Supabase:
   - Copy config.example.js to config.js
   - Add your Supabase project URL and public anon key
   - Ensure config.js is loaded by the pages (see README in the full project).
4. Do not publish real user accounts until authentication is configured and tested.
5. Never put a Supabase service-role key, Cloudflare API token, passwords, or verification codes in public files.
