const SUPABASE_URL = window.SECURELEARN_SUPABASE_URL || "";
const SUPABASE_ANON_KEY = window.SECURELEARN_SUPABASE_ANON_KEY || "";
let supabase = null;
async function getClient(){
  if(supabase) return supabase;
  if(!SUPABASE_URL || !SUPABASE_ANON_KEY) return null;
  const mod = await import("https://esm.sh/@supabase/supabase-js@2");
  supabase = mod.createClient(SUPABASE_URL,SUPABASE_ANON_KEY);
  return supabase;
}
function show(text, ok=false){const el=document.getElementById("msg"); if(!el)return; el.textContent=text;el.className="message show "+(ok?"ok":"bad");}
const form=document.getElementById("form");
if(form && location.pathname.endsWith("signup.html")){
 form.addEventListener("submit",async e=>{
  e.preventDefault();
  const client=await getClient();
  if(!client){show("Demo configuration only. Add your Supabase URL and anon key in config.js to enable real accounts.");return;}
  const email=document.getElementById("email").value.trim(), password=document.getElementById("password").value;
  const name=document.getElementById("name").value.trim(), level=document.getElementById("level").value;
  const {data,error}=await client.auth.signUp({email,password,options:{data:{display_name:name,training_level:level}}});
  if(error){show(error.message);return}
  if(data.user) show("Account created. Check your email and complete verification before logging in.",true);
 });
}
if(form && location.pathname.endsWith("login.html")){
 form.addEventListener("submit",async e=>{
  e.preventDefault(); const client=await getClient();
  if(!client){show("Demo configuration only. Add your Supabase URL and anon key in config.js to enable real login.");return;}
  const {data,error}=await client.auth.signInWithPassword({email:document.getElementById("email").value.trim(),password:document.getElementById("password").value});
  if(error){show(error.message);return}
  location.href="/dashboard.html";
 });
}
const logout=document.getElementById("logout");
if(logout) logout.addEventListener("click",async e=>{e.preventDefault();const c=await getClient();if(c)await c.auth.signOut();location.href="/";});
if(location.pathname.endsWith("dashboard.html")){
 (async()=>{const c=await getClient();if(!c)return;const {data}=await c.auth.getUser();if(!data.user){location.href="/login.html";return}document.getElementById("email").textContent=data.user.email||"";document.getElementById("hello").textContent=`Welcome, ${data.user.user_metadata?.display_name||"learner"}.`;})();
 document.querySelectorAll("[data-demo]").forEach(b=>b.addEventListener("click",()=>alert("Training module demo. Connect the lesson content and progress table to your database when ready.")));
}